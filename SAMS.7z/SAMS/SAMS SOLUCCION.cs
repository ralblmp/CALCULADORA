﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        Double resul=0 ;
        String operacion = "";
        bool operaciones = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void numero(object sender, EventArgs e)
        {
           
            if ((resultado.Text == "0") || (operaciones))
                resultado.Clear();

            operaciones = false;
            Button button = (Button)sender;
            if (button.Text == ".")
            {
                if(!resultado.Text.Contains("."))
                    resultado.Text = resultado.Text + button.Text;
            }
            else
            resultado.Text = resultado.Text + button.Text;

        }

        private void operador(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            if (resul != 0)
            {
                button15.PerformClick();
                operacion = button.Text;
                label3.Text = resul + "" + operacion;
                operaciones = true;

            }
            else
            {
                operacion = button.Text;
                resul = Double.Parse(resultado.Text);
                label3.Text = resul + " " + operacion;
                operaciones = true;
            }
        }

        private void ce_Click(object sender, EventArgs e)
        {
            resultado.Text = "0";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            resultado.Text = "0";
            resul = 0;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            switch (operacion)
            {
                case "+":
                    resultado.Text = (resul + Double.Parse(resultado.Text)).ToString();
                    break;
                case "-":
                    resultado.Text = (resul - Double.Parse(resultado.Text)).ToString();
                    break;
                case "*":
                    resultado.Text = (resul * Double.Parse(resultado.Text)).ToString();
                    break;
                case "/":
                    resultado.Text = (resul / Double.Parse(resultado.Text)).ToString();
                    break;
                default:
                    break;

            }
            resul = Double.Parse(resultado.Text);
            label3.Text = "";
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void resultado_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
